<?php
/**
 * Source view - displays file in raw form if possible
 */
$this->extend('../layout');
echo $source;